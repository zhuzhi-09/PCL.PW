# PCL.PW 图标素材

导出时间：2026-11-07
来源：F:\PCL.PW

## 目录

- `material/`：启动器代码中用到的 Material 图标，共 148 个，24×24，单色填充，来自 Flutter 自带的 Material Icons 字体（Apache-2.0）
- `loader/`：启动器自绘的加载器图标，共 10 个，24×24，线宽 2，`fill="none"` + `stroke`
- `app/`：PCL.PW 应用图标；`pclpw-logo.svg` 是按原图重绘的近似矢量版，`pclpw-logo-original.png` 是原始图片
- `preview.html`：在浏览器里预览全部图标
- `icons.json`：文件名与 Material codepoint 的对应表

## 使用说明

- Material 图标路径为黑色 `#000000`，可以按需改 `fill`
- 加载器图标为黑色描边，可以按需改 `stroke`
- 图标名与代码里的常量一致：`Icons.download` → `material/download.svg`
- 加载器名与 `Loader` 枚举一致：`Loader.forge` → `loader/forge.svg`

## 许可

- Material Icons：Apache License 2.0，见 `material/LICENSE-Apache-2.0.txt`
- 加载器图标与应用图标：PCL.PW 项目素材（项目代码 Apache-2.0）
